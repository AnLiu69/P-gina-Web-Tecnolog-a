/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Tienda.modelo.bean;

/**
 *
 * @author ADMIN
 */
public class Carrito {
    
    private int idcarrito;
    private int idarticulo;
    private int idcategoria;
    private int idcliente;
    private String nombreA;
    private String descripcionA;
    private float precioA;
    private String fotoA;
    private int cantidad;
    private String fecha;
    private float subtotal;

    public Carrito(int idcarrito, int idarticulo, int idcategoria, int idcliente, String nombreA, String descripcionA, float precioA, String fotoA, int cantidad, String fecha, float subtotal) {
        this.idcarrito = idcarrito;
        this.idarticulo = idarticulo;
        this.idcategoria = idcategoria;
        this.idcliente = idcliente;
        this.nombreA = nombreA;
        this.descripcionA = descripcionA;
        this.precioA = precioA;
        this.fotoA = fotoA;
        this.cantidad = cantidad;
        this.fecha = fecha;
        this.subtotal = subtotal;
    }

    public int getIdcarrito() {
        return idcarrito;
    }

    public void setIdcarrito(int idcarrito) {
        this.idcarrito = idcarrito;
    }

    public int getIdarticulo() {
        return idarticulo;
    }

    public void setIdarticulo(int idarticulo) {
        this.idarticulo = idarticulo;
    }

    public int getIdcategoria() {
        return idcategoria;
    }

    public void setIdcategoria(int idcategoria) {
        this.idcategoria = idcategoria;
    }

    public int getIdcliente() {
        return idcliente;
    }

    public void setIdcliente(int idcliente) {
        this.idcliente = idcliente;
    }

    public String getNombreA() {
        return nombreA;
    }

    public void setNombreA(String nombreA) {
        this.nombreA = nombreA;
    }

    public String getDescripcionA() {
        return descripcionA;
    }

    public void setDescripcionA(String descripcionA) {
        this.descripcionA = descripcionA;
    }

    public float getPrecioA() {
        return precioA;
    }

    public void setPrecioA(float precioA) {
        this.precioA = precioA;
    }

    public String getFotoA() {
        return fotoA;
    }

    public void setFotoA(String fotoA) {
        this.fotoA = fotoA;
    }

    public int getCantidad() {
        return cantidad;
    }

    public void setCantidad(int cantidad) {
        this.cantidad = cantidad;
    }

    public String getFecha() {
        return fecha;
    }

    public void setFecha(String fecha) {
        this.fecha = fecha;
    }

    public float getSubtotal() {
        return subtotal;
    }

    public void setSubtotal(float subtotal) {
        this.subtotal = subtotal;
    }
    
    
    
}
