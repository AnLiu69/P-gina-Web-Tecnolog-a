/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Tienda.modelo.bean;

/**
 *
 * @author ADMIN
 */
public class Cliente {
    
    private int idCliente;
    private String Nombres;
    private String ApellidoP;
    private String ApellidoM;
    private String email;
    private int idpais;

    public Cliente(int idCliente, String Nombres, String ApellidoP, String ApellidoM, String email, int idpais) {
        this.idCliente = idCliente;
        this.Nombres = Nombres;
        this.ApellidoP = ApellidoP;
        this.ApellidoM = ApellidoM;
        this.email = email;
        this.idpais = idpais;
    }

    public Cliente() {
    }

    
    public int getIdCliente() {
        return idCliente;
    }

    public void setIdCliente(int idCliente) {
        this.idCliente = idCliente;
    }

    public String getNombres() {
        return Nombres;
    }

    public void setNombres(String Nombres) {
        this.Nombres = Nombres;
    }

    public String getApellidoP() {
        return ApellidoP;
    }

    public void setApellidoP(String ApellidoP) {
        this.ApellidoP = ApellidoP;
    }

    public String getApellidoM() {
        return ApellidoM;
    }

    public void setApellidoM(String ApellidoM) {
        this.ApellidoM = ApellidoM;
    }

    public String getEmail() {
        return email;
    }

    public void setEmail(String email) {
        this.email = email;
    }

    public int getIdpais() {
        return idpais;
    }

    public void setIdpais(int idpais) {
        this.idpais = idpais;
    }
    
    
}
