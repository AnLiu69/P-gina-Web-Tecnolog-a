/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Tienda.modelo.bean;

/**
 *
 * @author ADMIN
 */
public class PedidoDetalle {
    
    private int idpedido_detalle;
    private int idpedido;
    private int idarticulo;
    private float precio;
    private int cantidad;
    private float subtotal;

    public PedidoDetalle(int idpedido_detalle, int idpedido, int idarticulo, float precio, int cantidad, float subtotal) {
        this.idpedido_detalle = idpedido_detalle;
        this.idpedido = idpedido;
        this.idarticulo = idarticulo;
        this.precio = precio;
        this.cantidad = cantidad;
        this.subtotal = subtotal;
    }

    public int getIdpedido_detalle() {
        return idpedido_detalle;
    }

    public void setIdpedido_detalle(int idpedido_detalle) {
        this.idpedido_detalle = idpedido_detalle;
    }

    public int getIdpedido() {
        return idpedido;
    }

    public void setIdpedido(int idpedido) {
        this.idpedido = idpedido;
    }

    public int getIdarticulo() {
        return idarticulo;
    }

    public void setIdarticulo(int idarticulo) {
        this.idarticulo = idarticulo;
    }

    public float getPrecio() {
        return precio;
    }

    public void setPrecio(float precio) {
        this.precio = precio;
    }

    public int getCantidad() {
        return cantidad;
    }

    public void setCantidad(int cantidad) {
        this.cantidad = cantidad;
    }

    public float getSubtotal() {
        return subtotal;
    }

    public void setSubtotal(float subtotal) {
        this.subtotal = subtotal;
    }
    
    
}
