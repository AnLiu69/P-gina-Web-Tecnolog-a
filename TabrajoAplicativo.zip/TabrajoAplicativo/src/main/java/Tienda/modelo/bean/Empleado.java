/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Tienda.modelo.bean;

/**
 *
 * @author ADMIN
 */
public class Empleado {
    
    private int idempleado;
    private String nombres;
    private String apaterno;
    private String amaterno;

    public Empleado(int idempleado, String nombres, String apaterno, String amaterno) {
        this.idempleado = idempleado;
        this.nombres = nombres;
        this.apaterno = apaterno;
        this.amaterno = amaterno;
    }

    public int getIdempleado() {
        return idempleado;
    }

    public void setIdempleado(int idempleado) {
        this.idempleado = idempleado;
    }

    public String getNombres() {
        return nombres;
    }

    public void setNombres(String nombres) {
        this.nombres = nombres;
    }

    public String getApaterno() {
        return apaterno;
    }

    public void setApaterno(String apaterno) {
        this.apaterno = apaterno;
    }

    public String getAmaterno() {
        return amaterno;
    }

    public void setAmaterno(String amaterno) {
        this.amaterno = amaterno;
    }
    
    
}
