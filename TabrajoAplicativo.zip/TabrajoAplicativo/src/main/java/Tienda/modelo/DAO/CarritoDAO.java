/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Tienda.modelo.DAO;

import Tienda.Conexion.Conexion;
import Tienda.modelo.bean.Carrito;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.logging.Level;
import java.util.logging.Logger;

/**
 *
 * @author ADMIN
 */
public class CarritoDAO {
    
    public static void insertar(Carrito car){
        //Instruccion SQL para insertar empleado en la bd
        String sql = "insert into carrito(idarticulo, idcategoria, idcliente, nombreA, descripcionA, precioA, fotoA, cantidad, fecha, subtotal) values (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)";

        //Conexion con la bd
        Connection cn = Conexion.abrir();

            
        try {
            //ejecutar instruccion sql
            PreparedStatement ps;
            ps = cn.prepareStatement(sql);
            
            //asignar valor a los parametros ?, ?, ?, ?
            ps.setInt(1, car.getIdarticulo());
            ps.setInt(2, car.getIdcategoria());
            ps.setInt(3, car.getIdcliente());
            ps.setString(4, car.getNombreA());
            ps.setString(5, car.getDescripcionA());
            ps.setFloat(6, car.getPrecioA());
            ps.setString(7, car.getFotoA());
            ps.setInt(8, car.getCantidad());
            ps.setString(9, car.getFecha());
            ps.setFloat(10, car.getSubtotal());
            //ejecutar
            ps.executeUpdate(); //para hacer 
            //cerrar objetos
            cn.close();
            ps.close();
        } catch (SQLException ex) {
            Logger.getLogger(CarritoDAO.class.getName()).log(Level.SEVERE, null, ex);
        }
    }
    
    public static ArrayList<Carrito> listar() throws SQLException{
        //Variable de tipo Articulo
        Carrito car;
        //arreglo de objetos empleados
        ArrayList<Carrito> listcar = new ArrayList<>();
        String sql = "select * from carrito";
        //conexion a la base de datos
        Connection cn = Conexion.abrir();
        //ejecutar sql
        PreparedStatement ps = cn.prepareStatement(sql);
        //ejecutar 
        ResultSet rs = ps.executeQuery();
        
        while(rs.next()){
            //crear objeto 
            car = new Carrito(rs.getInt(1), rs.getInt(2), rs.getInt(3), rs.getInt(4), rs.getString(5), rs.getString(6), rs.getFloat(7), rs.getString(8), rs.getInt(9), rs.getString(10), rs.getFloat(11));
            listcar.add(car);
        }
        //cerrar
        return listcar;
    }
    
    public static void eliminarArt (int cod){
        
        //SQL PARA ELIMINAR EMPLEADO
            String sql = "delete from carrito where idcarrito=?";
            //Conexion a la bd
            Connection cn = Conexion.abrir();
        try {
            PreparedStatement ps = cn.prepareStatement(sql);
            //asignar valores a los parametros
            ps.setInt(1, cod);
            //ejecutar
            ps.executeUpdate();
            //cerrar objetos
            cn.close();
            ps.close();
        } catch (SQLException ex) {
            Logger.getLogger(CarritoDAO.class.getName()).log(Level.SEVERE, null, ex);
        }
    }
    public static ArrayList<Carrito> listarCli(int idcli) throws SQLException{
        //Variable de tipo Empleado
        Carrito carr;
        //arreglo de objetos empleados
        ArrayList<Carrito> carritolista = new ArrayList<>();
        String sql = "select * from carrito where idcliente = ?";
        //conexion a la base de datos
        Connection cn = Conexion.abrir();
        //ejecutar sql
        PreparedStatement ps = cn.prepareStatement(sql);
        //asignar valores a los parametros
            ps.setInt(1, idcli);
        //ejecutar 
        ResultSet rs = ps.executeQuery();
        
        while(rs.next()){
            //crear objeto 
            carr = new Carrito(rs.getInt(1), rs.getInt(2), rs.getInt(3), rs.getInt(4), rs.getString(5), rs.getString(6), rs.getFloat(7), rs.getString(8), rs.getInt(9), rs.getString(10), rs.getFloat(11));
            carritolista.add(carr);
        }
        //cerrar
        return carritolista;
    }
    public static  Carrito EncontrarFech(int idcli) throws SQLException{
        //Variable de tipo Empleado
        Carrito carr = null;
        //arreglo de objetos empleados
        String sql = "select * from carrito where idcliente = ? and fecha = (select MAX(fecha) from carrito) LIMIT 1";
        //conexion a la base de datos
        Connection cn = Conexion.abrir();
        //ejecutar sql
        try {
        PreparedStatement ps = cn.prepareStatement(sql);
        //asignar valores a los parametros
            ps.setInt(1, idcli);
        //ejecutar 
         ResultSet rs = ps.executeQuery();
            if(rs.next()){
             //objeto empleado
             carr = new Carrito(rs.getInt(1), rs.getInt(2), rs.getInt(3), rs.getInt(4), rs.getString(5), rs.getString(6), rs.getFloat(7), rs.getString(8), rs.getInt(9), rs.getString(10), rs.getFloat(1));
             //asignar valores a las propiedades 
             //del objeto empleado:encapsulamiento
             carr.setIdcarrito(rs.getInt("idcarrito"));
             carr.setIdarticulo(rs.getInt("idarticulo"));
             carr.setIdcategoria(rs.getInt("idcategoria"));
             carr.setIdcliente(rs.getInt("idcliente"));
             carr.setNombreA(rs.getString("nombreA"));
             carr.setDescripcionA(rs.getString("descripcionA")); 
             carr.setPrecioA(rs.getFloat("precioA")); 
             carr.setFotoA(rs.getString("fotoA")); 
             carr.setCantidad(rs.getInt("cantidad")); 
             carr.setFecha(rs.getString("fecha")); 
             carr.setSubtotal(rs.getFloat("subtotal")); 
            }
        } catch (SQLException ex) {
            Logger.getLogger(CarritoDAO.class.getName()).log(Level.SEVERE, null, ex);
        }
        //cerrar
        return carr;
    }
}
