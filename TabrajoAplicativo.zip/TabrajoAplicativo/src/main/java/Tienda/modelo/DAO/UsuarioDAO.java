/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Tienda.modelo.DAO;

import Tienda.Conexion.Conexion;
import Tienda.modelo.bean.Usuario;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.logging.Level;
import java.util.logging.Logger;

/**
 *
 * @author ADMIN
 */
public class UsuarioDAO {
    
    public static Usuario validarUsuario(String us,String pas) {
        //variable tipo usuario
        Usuario user=null;
        //instruccion sql para buscar usuario
        String sql="Select*from usuario where usuario=? and password=?";
        //conexion a la bd
        Connection cn = Conexion.abrir();
        try {
            //ejecutar sql
            PreparedStatement ps=cn.prepareStatement(sql);
            //asignar parametros ?,?
            ps.setString(1, us);
            ps.setString(2, pas);
            //metodo que la ejecuta
         ResultSet rs=   ps.executeQuery();
         //leer rs
         if(rs.next()){
             //objeto usuario
             user = new Usuario(rs.getInt(1), rs.getString(2), rs.getString(3), rs.getInt(4));
             //asignar valores a las propiedades 
             //del objeto usuario:encapsulamiento
             user.setIdusuario(rs.getInt("idusuario"));
             user.setUsuario(rs.getString("usuario"));
             user.setContraseña(rs.getString("password"));
             user.setIdempleado(rs.getInt("idempleado"));       
         }
            
        } catch (SQLException ex) {
            Logger.getLogger(UsuarioDAO.class.getName()).log(Level.SEVERE, null, ex);
        }
        return user;
    }
}
