/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Tienda.modelo.DAO;

import Tienda.Conexion.Conexion;
import Tienda.modelo.bean.Cliente;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.logging.Level;
import java.util.logging.Logger;

/**
 *
 * @author ADMIN
 */
public class ClienteDAO {
    
    public static Cliente validarCliente(String ap, String em) {
        //variable tipo usuario
        Cliente cliente = null;
        //instruccion sql para buscar usuario
        String sql="select * from cliente where apellidoP = ? and email = ?";
        //conexion a la bd
        Connection cn = Conexion.abrir();
        try {
            //ejecutar sql
            PreparedStatement ps=cn.prepareStatement(sql);
            //asignar parametros ?,?
            ps.setString(1, ap);
            ps.setString(2, em);
            //metodo que la ejecuta
         ResultSet rs =   ps.executeQuery();
         //leer rs
         if(rs.next()){
             
            cliente = new Cliente(rs.getInt(1), rs.getString(2), rs.getString(3),rs.getString(4), rs.getString(5), rs.getInt(6));
             //asignar valores a las propiedades 
             //del objeto usuario:encapsulamiento
            cliente.setIdCliente(rs.getInt("idcliente"));
            cliente.setNombres(rs.getString("nombres"));
            cliente.setApellidoP(rs.getString("apellidoP"));
            cliente.setApellidoM(rs.getString("apellidoM"));
            cliente.setEmail(rs.getString("email"));
            cliente.setIdpais(rs.getInt("idpais"));
        }       
            
        } catch (SQLException ex) {
            Logger.getLogger(ClienteDAO.class.getName()).log(Level.SEVERE, null, ex);
        }
        return cliente;
    }
    
    public static void insertar(Cliente cli){
        //Instruccion SQL para insertar empleado en la bd
        String sql = "insert into cliente(idcliente, nombres, apellidoP, apellidoM, email, idpais) values (?, ?, ?, ?, ?, ?)";

        //Conexion con la bd
        Connection cn = Conexion.abrir();

            
        try {
            //ejecutar instruccion sql
            PreparedStatement ps;
            ps = cn.prepareStatement(sql);
            
            //asignar valor a los parametros ?, ?, ?, ?
            ps.setInt(1, cli.getIdCliente());
            ps.setString(2, cli.getNombres());
            ps.setString(3, cli.getApellidoP());
            ps.setString(4, cli.getApellidoM());
            ps.setString(5, cli.getEmail());
            ps.setInt(6, cli.getIdpais());
            //ejecutar
            ps.executeUpdate(); //para hacer 
            //cerrar objetos
            cn.close();
            ps.close();
        } catch (SQLException ex) {
            Logger.getLogger(ClienteDAO.class.getName()).log(Level.SEVERE, null, ex);
        }
    }
}
