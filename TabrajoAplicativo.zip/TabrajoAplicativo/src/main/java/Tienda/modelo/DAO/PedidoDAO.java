/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Tienda.modelo.DAO;

import Tienda.Conexion.Conexion;
import Tienda.modelo.bean.Pedido;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.logging.Level;
import java.util.logging.Logger;

/**
 *
 * @author ADMIN
 */
public class PedidoDAO {
    
    public static void insertar(Pedido ped){
        //Instruccion SQL para insertar empleado en la bd
        String sql = "insert into pedido(fecha, total, idcliente, idempleado) values (?, ?, ?, ?)";

        //Conexion con la bd
        Connection cn = Conexion.abrir();

            
        try {
            //ejecutar instruccion sql
            PreparedStatement ps;
            ps = cn.prepareStatement(sql);

            //asignar valor a los parametros ?, ?, ?, ?
            ps.setString(1, ped.getFecha());
            ps.setFloat(2, ped.getTotal());
            ps.setInt(3, ped.getIdcliente());
            ps.setInt(4, ped.getIdempleado());
            //ejecutar
            ps.executeUpdate(); //para hacer 
            //cerrar objetos
            cn.close();
            ps.close();
        } catch (SQLException ex) {
            Logger.getLogger(PedidoDAO.class.getName()).log(Level.SEVERE, null, ex);
        }
    }
    public static Pedido seleccionarID(int idcli){
        //Instruccion SQL para insertar empleado en la bd
        String sql = "select * from pedido where idcliente = ? and idpedido = (select MAX(idpedido) from pedido)";
        Pedido ped = null;
        //Conexion con la bd
        Connection cn = Conexion.abrir();

            
        try {
            //ejecutar instruccion sql
            PreparedStatement ps;
            ps = cn.prepareStatement(sql);
            
            ps.setInt(1, idcli);
            
            ResultSet rs = ps.executeQuery();
            if(rs.next()){
             //objeto empleado
             ped = new Pedido(rs.getInt(1), rs.getString(2), rs.getFloat(3), rs.getInt(4), rs.getInt(5));
             //asignar valores a las propiedades 
             //del objeto empleado:encapsulamiento
             ped.setIdpedido(rs.getInt("idpedido"));
             ped.setFecha(rs.getString("fecha"));
             ped.setTotal(rs.getFloat("total"));
             ped.setIdcliente(rs.getInt("idcliente"));
             ped.setIdempleado(rs.getInt("idempleado"));  
            }
        } catch (SQLException ex) {
            Logger.getLogger(PedidoDAO.class.getName()).log(Level.SEVERE, null, ex);
        }
         return ped;
    } 
}
