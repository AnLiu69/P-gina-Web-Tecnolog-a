/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Tienda.modelo.DAO;

import Tienda.Conexion.Conexion;
import Tienda.modelo.bean.Pais;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.logging.Level;
import java.util.logging.Logger;

/**
 *
 * @author ADMIN
 */
public class PaisDAO {
    
    public static Pais obtenerPais(int idp) {
        //variable tipo usuario
        Pais pas = null;
        //instruccion sql para buscar usuario
        String sql="select*from pais where idpais=?";
        //conexion a la bd
        Connection cn = Conexion.abrir();
        try {
            //ejecutar sql
            PreparedStatement ps;
            ps = cn.prepareStatement(sql);
            //asignar parametro ? 
            ps.setInt(1, idp);
            //metodo que la ejecuta
            ResultSet rs = ps.executeQuery();
         //leer rs
         if(rs.next()){
             //objeto empleado
             pas = new Pais(rs.getInt(1), rs.getString(2));
             //asignar valores a las propiedades 
             //del objeto empleado:encapsulamiento
             pas.setIdpais(rs.getInt("idpais"));
             pas.setPais(rs.getString("pais"));      
         }
            
        } catch (SQLException ex) {
            Logger.getLogger(EmpleadoDAO.class.getName()).log(Level.SEVERE, null, ex);
        }
        return pas;
    }
}
