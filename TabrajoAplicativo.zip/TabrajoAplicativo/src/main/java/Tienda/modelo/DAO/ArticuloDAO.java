/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Tienda.modelo.DAO;

import Tienda.Conexion.Conexion;
import Tienda.modelo.bean.Articulo;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.logging.Level;
import java.util.logging.Logger;

/**
 *
 * @author ADMIN
 */
public class ArticuloDAO {
    
    public static ArrayList<Articulo> listar() throws SQLException{
        //Variable de tipo Articulo
        Articulo art;
        //arreglo de objetos articulos
        ArrayList<Articulo> articulos = new ArrayList<>();
        String sql = "select * from articulo";
        //conexion a la base de datos
        Connection cn = Conexion.abrir();
        //ejecutar sql
        PreparedStatement ps = cn.prepareStatement(sql);
        //ejecutar 
        ResultSet rs = ps.executeQuery();
        
        while(rs.next()){
            //crear objeto 
            art = new Articulo(rs.getInt(1), rs.getString(2), rs.getString(3), rs.getFloat(4), rs.getString(5), rs.getInt(6));
            articulos.add(art);
        }
        //cerrar
        return articulos;
    }
    
    public static ArrayList<Articulo> listarAZ() throws SQLException{
        //Variable de tipo Articulo
        Articulo art;
        //arreglo de objetos articulos
        ArrayList<Articulo> articulos = new ArrayList<>();
        String sql = "select * from articulo order by nombre";
        //conexion a la base de datos
        Connection cn = Conexion.abrir();
        //ejecutar sql
        PreparedStatement ps = cn.prepareStatement(sql);
        //ejecutar 
        ResultSet rs = ps.executeQuery();
        
        while(rs.next()){
            //crear objeto 
            art = new Articulo(rs.getInt(1), rs.getString(2), rs.getString(3), rs.getFloat(4), rs.getString(5), rs.getInt(6));
            articulos.add(art);
        }
        //cerrar
        return articulos;
    }
    public static ArrayList<Articulo> listarCostoso() throws SQLException{
        //Variable de tipo Articulo
        Articulo art;
        //arreglo de objetos articulos
        ArrayList<Articulo> articulos = new ArrayList<>();
        String sql = "select * from articulo order by precio desc";
        //conexion a la base de datos
        Connection cn = Conexion.abrir();
        //ejecutar sql
        PreparedStatement ps = cn.prepareStatement(sql);
        //ejecutar 
        ResultSet rs = ps.executeQuery();
        
        while(rs.next()){
            //crear objeto 
            art = new Articulo(rs.getInt(1), rs.getString(2), rs.getString(3), rs.getFloat(4), rs.getString(5), rs.getInt(6));
            articulos.add(art);
        }
        //cerrar
        return articulos;
    }
    
    public static ArrayList<Articulo> listarCat(int cat) throws SQLException{
        //Variable de tipo Articulo
        Articulo art;
        //arreglo de objetos articulos
        ArrayList<Articulo> articulos = new ArrayList<>();
        String sql = "select * from articulo where idcategoria = ?";
        //conexion a la base de datos
        Connection cn = Conexion.abrir();
        //ejecutar sql
        PreparedStatement ps = cn.prepareStatement(sql);
        //asignar parametro ? 
            ps.setInt(1, cat);
        //ejecutar 
        ResultSet rs = ps.executeQuery();
        
        while(rs.next()){
            //crear objeto 
            art = new Articulo(rs.getInt(1), rs.getString(2), rs.getString(3), rs.getFloat(4), rs.getString(5), rs.getInt(6));
            articulos.add(art);
        }
        //cerrar
        return articulos;
    }
    
    public static void eliminar (int cod){
        
        //SQL PARA ELIMINAR Articulo
            String sql = "delete from articulo where idarticulo = ?";
            //Conexion a la bd
            Connection cn = Conexion.abrir();
        try {
            PreparedStatement ps = cn.prepareStatement(sql);
            //asignar valores a los parametros
            ps.setInt(1, cod);
            //ejecutar
            ps.executeUpdate();
            //cerrar objetos
            cn.close();
            ps.close();
        } catch (SQLException ex) {
            Logger.getLogger(ArticuloDAO.class.getName()).log(Level.SEVERE, null, ex);
        }
    }
    
    public static void editar (Articulo art){
        String sql = "update articulo set nombre = ?, descripcion = ?, precio = ?, foto = ?, idcategoria = ? where idarticulo = ?";
        //Conexion a la bd
        Connection cn = Conexion.abrir();
        
        try {
            PreparedStatement ps = cn.prepareStatement(sql);
            //asignar valores a los parametros
            ps.setString(1, art.getNombre());
            ps.setString(2, art.getDescripcion());
            ps.setFloat(3, art.getPrecio());
            ps.setString(4, art.getFoto());
            ps.setInt(5, art.getIdcategoria());
            ps.setInt(6, art.getIdarticulo());
            //ejecutar
            ps.executeUpdate();
            //cerrar objetos
            cn.close();
            ps.close();   
        } catch (SQLException ex) {
            Logger.getLogger(ArticuloDAO.class.getName()).log(Level.SEVERE, null, ex);
        }
        
    }
    
    public static void insertar(Articulo art){
        //Instruccion SQL para insertar empleado en la bd
        String sql = "insert into articulo (nombre, descripcion, precio, foto, idcategoria) values (?, ?, ?, ?, ?)";

        //Conexion con la bd
        Connection cn = Conexion.abrir();

            
        try {
            //ejecutar instruccion sql
            PreparedStatement ps;
            ps = cn.prepareStatement(sql);
            
            //asignar valor a los parametros ?, ?, ?, ?
            ps.setString(1, art.getNombre());
            ps.setString(2, art.getDescripcion());
            ps.setFloat(3, art.getPrecio());
            ps.setString(4, art.getFoto());
            ps.setInt(5, art.getIdcategoria());
            //ejecutar
            ps.executeUpdate(); //para hacer 
            //cerrar objetos
            cn.close();
            ps.close();
        } catch (SQLException ex) {
            Logger.getLogger(ArticuloDAO.class.getName()).log(Level.SEVERE, null, ex);
        }
    }
}
