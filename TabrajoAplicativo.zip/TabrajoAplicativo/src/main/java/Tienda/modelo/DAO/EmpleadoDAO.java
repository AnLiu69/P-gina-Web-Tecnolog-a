/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Tienda.modelo.DAO;

import Tienda.Conexion.Conexion;
import Tienda.modelo.bean.Empleado;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.logging.Level;
import java.util.logging.Logger;

/**
 *
 * @author ADMIN
 */
public class EmpleadoDAO {
    
    public static ArrayList<Empleado> listar() throws SQLException{
        //Variable de tipo Articulo
        Empleado emp;
        //arreglo de objetos empleados
        ArrayList<Empleado> empleados = new ArrayList<>();
        String sql = "select * from empleado";
        //conexion a la base de datos
        Connection cn = Conexion.abrir();
        //ejecutar sql
        PreparedStatement ps = cn.prepareStatement(sql);
        //ejecutar 
        ResultSet rs = ps.executeQuery();
        
        while(rs.next()){
            //crear objeto 
            emp = new Empleado(rs.getInt(1), rs.getString(2), rs.getString(3), rs.getString(4));
            empleados.add(emp);
        }
        //cerrar
        return empleados;
    }
    
    public static Empleado obtenerEmpleado(int idp) {
        //variable tipo usuario
        Empleado empl = null;
        //instruccion sql para buscar usuario
        String sql="Select*from empleado where idempleado=?";
        //conexion a la bd
        Connection cn = Conexion.abrir();
        try {
            //ejecutar sql
            PreparedStatement ps=cn.prepareStatement(sql);
            //asignar parametro ? 
            ps.setInt(1, idp);
            //metodo que la ejecuta
         ResultSet rs = ps.executeQuery();
         //leer rs
         if(rs.next()){
             //objeto empleado
             empl = new Empleado(idp, sql, sql, sql);
             //asignar valores a las propiedades 
             //del objeto empleado:encapsulamiento
             empl.setIdempleado(rs.getInt("idempleado"));
             empl.setNombres(rs.getString("nombres"));
             empl.setApaterno(rs.getString("apellidoP"));
             empl.setAmaterno(rs.getString("apellidoM"));      
         }
            
        } catch (SQLException ex) {
            Logger.getLogger(EmpleadoDAO.class.getName()).log(Level.SEVERE, null, ex);
        }
        return empl;
    }
}
