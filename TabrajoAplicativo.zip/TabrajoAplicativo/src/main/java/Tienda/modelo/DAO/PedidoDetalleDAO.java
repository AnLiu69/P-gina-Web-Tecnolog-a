/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Tienda.modelo.DAO;

import Tienda.Conexion.Conexion;
import Tienda.modelo.bean.PedidoDetalle;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.util.logging.Level;
import java.util.logging.Logger;

/**
 *
 * @author ADMIN
 */
public class PedidoDetalleDAO {
    
     public static void insertar(PedidoDetalle ped){
        //Instruccion SQL para insertar empleado en la bd
        String sql = "insert into pedido_detalle(idpedido, idarticulo, precio, cantidad, subtotal) values (?, ?, ?, ?, ?)";

        //Conexion con la bd
        Connection cn = Conexion.abrir();

            
        try {
            //ejecutar instruccion sql
            PreparedStatement ps;
            ps = cn.prepareStatement(sql);
            
            //asignar valor a los parametros ?, ?, ?, ?
            ps.setInt(1, ped.getIdpedido());
            ps.setInt(2, ped.getIdarticulo());
            ps.setFloat(3, ped.getPrecio());
            ps.setInt(4, ped.getCantidad());
            ps.setFloat(5, ped.getSubtotal());
            //ejecutar
            ps.executeUpdate(); //para hacer 
            //cerrar objetos
            cn.close();
            ps.close();
        } catch (SQLException ex) {
            Logger.getLogger(PedidoDetalleDAO.class.getName()).log(Level.SEVERE, null, ex);
        }
    } 
}
