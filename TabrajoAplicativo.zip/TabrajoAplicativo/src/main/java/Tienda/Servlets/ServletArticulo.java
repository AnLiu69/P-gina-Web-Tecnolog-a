/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Tienda.Servlets;

import Tienda.modelo.DAO.ArticuloDAO;
import Tienda.modelo.DAO.CarritoDAO;
import Tienda.modelo.bean.Articulo;
import Tienda.modelo.bean.Carrito;
import Tienda.modelo.bean.Cliente;
import java.io.IOException;
import java.io.PrintWriter;
import java.sql.SQLException;
import java.time.LocalDate;
import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

/**
 *
 * @author ADMIN
 */
@WebServlet(name = "ServletArticulo", urlPatterns = {"/ServletArticulo", "/Carri", "/EliminarArt", "/EditarArt", "/Editpt2", "/NuevoArt", "/AgregarArt"})
public class ServletArticulo extends HttpServlet {

    /**
     * Processes requests for both HTTP <code>GET</code> and <code>POST</code>
     * methods.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    protected void processRequest(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException, SQLException {
        response.setContentType("text/html;charset=UTF-8");
        try (PrintWriter out = response.getWriter()) {
            String path = request.getServletPath();
            
            if(path.equals("/Carri")){
                HttpSession session1 = request.getSession(false);
                if(session1 != null && session1.getAttribute("cliente") != null){
                    int idart = Integer.parseInt(request.getParameter("idart"));
                    String nom = (String)(request.getParameter("nom"));
                    String dsc = (String)(request.getParameter("dsc"));
                    float prec = Float.parseFloat(request.getParameter("prec"));
                    String fot = (String)(request.getParameter("fot"));
                    int idcat = Integer.parseInt(request.getParameter("idcat"));
                    int cant = Integer.parseInt(request.getParameter("product-quanity"));
                    String fech = "" + LocalDate.now();
                    float subt = prec * cant;
                    HttpSession session = request.getSession();
                    Cliente cliente = (Cliente)session.getAttribute("cliente");
                    int idcli = cliente.getIdCliente();
                    
                    Carrito carrito = new Carrito(0, idart, idcat, idcli, nom, dsc, prec, fot, cant, fech, subt);
                    CarritoDAO.insertar(carrito);
                    ArrayList<Float> subts = new ArrayList<Float>();
                    ArrayList<Carrito> carritolista = CarritoDAO.listarCli(idcli);
                    for(Carrito x: carritolista){
                        subts.add(x.getSubtotal());
                    }
                    float suma = 0;
                    for (float numero : subts) {
                        suma += numero;
                    }
                    request.setAttribute("total", suma);
                    request.setAttribute("listacarrito", CarritoDAO.listarCli(idcli));
                    request.getRequestDispatcher("WEB-INF/Carrito.jsp").forward(request, response);
                }
                else{
                    request.getRequestDispatcher("WEB-INF/Login.jsp").forward(request, response);
                }
            }
            
            if(path.equals("/EliminarArt")){
                int idart = Integer.parseInt(request.getParameter("id"));
                ArticuloDAO.eliminar(idart);
                ArrayList<Articulo> articulos = new ArrayList<>();
                articulos = ArticuloDAO.listar();
                request.setAttribute("articulos", articulos);
                request.getRequestDispatcher("WEB-INF/Tienda.jsp").forward(request, response);
            }
            if(path.equals("/EditarArt")){
                int id = Integer.parseInt(request.getParameter("id"));
                String nom = (String)(request.getParameter("nom"));
                String dsc = (String)(request.getParameter("dsc"));
                float precio = Float.parseFloat(request.getParameter("prec"));
                String foto = (String)(request.getParameter("fot"));
                int idcat = Integer.parseInt(request.getParameter("idcat"));
                Articulo art = new Articulo (id, nom, dsc, precio, foto, idcat);
                request.setAttribute("articulo", art);
                //Redireccionar
                request.getRequestDispatcher("WEB-INF/EditArt.jsp").forward(request, response);
            }
            if(path.equals("/Editpt2")){
                String nom = request.getParameter("nom");
                String dsc = request.getParameter("dsc");
                float prec = Float.parseFloat(request.getParameter("prec"));
                String fot = request.getParameter("fot");
                int idcat = Integer.parseInt(request.getParameter("idcat"));
                int idart = Integer.parseInt(request.getParameter("idart"));
                Articulo art = new Articulo (idart, nom, dsc, prec, fot, idcat);
                ArticuloDAO.editar(art);
                request.setAttribute("articulos", ArticuloDAO.listar());
                //Redireccionar
                request.getRequestDispatcher("WEB-INF/Tienda.jsp").forward(request, response);
            }
            if(path.equals("/NuevoArt")){
                request.getRequestDispatcher("WEB-INF/FormArt.jsp").forward(request, response);
            }
            if(path.equals("/AgregarArt")){
                String nom = request.getParameter("nom");
                String dsc = request.getParameter("dsc");
                float prec = Float.parseFloat(request.getParameter("prec"));
                String fot = request.getParameter("fot");
                int idcat = Integer.parseInt(request.getParameter("idcat"));
                Articulo art = new Articulo (0, nom, dsc, prec, fot, idcat);
                ArticuloDAO.insertar(art);
                request.setAttribute("articulos", ArticuloDAO.listar());
                request.getRequestDispatcher("WEB-INF/Tienda.jsp").forward(request, response);
            }
        }
    }

    // <editor-fold defaultstate="collapsed" desc="HttpServlet methods. Click on the + sign on the left to edit the code.">
    /**
     * Handles the HTTP <code>GET</code> method.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        try {
            processRequest(request, response);
        } catch (SQLException ex) {
            Logger.getLogger(ServletArticulo.class.getName()).log(Level.SEVERE, null, ex);
        }
    }

    /**
     * Handles the HTTP <code>POST</code> method.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        try {
            processRequest(request, response);
        } catch (SQLException ex) {
            Logger.getLogger(ServletArticulo.class.getName()).log(Level.SEVERE, null, ex);
        }
    }

    /**
     * Returns a short description of the servlet.
     *
     * @return a String containing servlet description
     */
    @Override
    public String getServletInfo() {
        return "Short description";
    }// </editor-fold>

}
