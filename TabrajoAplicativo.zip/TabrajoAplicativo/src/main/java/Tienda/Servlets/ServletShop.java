/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Tienda.Servlets;

import Tienda.modelo.DAO.ArticuloDAO;
import Tienda.modelo.DAO.CarritoDAO;
import Tienda.modelo.DAO.EmpleadoDAO;
import Tienda.modelo.DAO.PedidoDAO;
import Tienda.modelo.DAO.PedidoDetalleDAO;
import Tienda.modelo.bean.Articulo;
import Tienda.modelo.bean.Carrito;
import Tienda.modelo.bean.Cliente;
import Tienda.modelo.bean.Empleado;
import Tienda.modelo.bean.Pedido;
import Tienda.modelo.bean.PedidoDetalle;
import java.io.IOException;
import java.io.PrintWriter;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.Random;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

/**
 *
 * @author ADMIN
 */
@WebServlet(name = "ServletShop", urlPatterns = {"/ServletShop", "/Tienda", "/TiendaPC", "/TiendaV", "/TiendaE", "/TiendaA", "/TiendaAZ", "/Costoso", "/ShopS", "/Seguir"})
public class ServletShop extends HttpServlet {

    /**
     * Processes requests for both HTTP <code>GET</code> and <code>POST</code>
     * methods.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    protected void processRequest(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException, SQLException {
        response.setContentType("text/html;charset=UTF-8");
        try (PrintWriter out = response.getWriter()) {
            String path = request.getServletPath();
            
            if(path.equals("/Tienda")){
                request.setAttribute("articulos", ArticuloDAO.listar());
                request.getRequestDispatcher("shop.jsp").forward(request, response);
            }
            if(path.equals("/TiendaAZ")){
                request.setAttribute("articulos", ArticuloDAO.listarAZ());
                request.getRequestDispatcher("WEB-INF/TiendaAZ.jsp").forward(request, response);
            }
            if(path.equals("/Costoso")){
                request.setAttribute("articulos", ArticuloDAO.listarCostoso());
                request.getRequestDispatcher("WEB-INF/TiendaCostoso.jsp").forward(request, response);
            }
            if(path.equals("/TiendaPC")){
                int idcat = 4;
                request.setAttribute("articulos", ArticuloDAO.listarCat(idcat));
                request.getRequestDispatcher("WEB-INF/TiendaPC.jsp").forward(request, response);
            }
            if(path.equals("/TiendaV")){
                int idcat = 2;
                request.setAttribute("articulos", ArticuloDAO.listarCat(idcat));
                request.getRequestDispatcher("WEB-INF/TiendaV.jsp").forward(request, response);
            }
            if(path.equals("/TiendaE")){
                int idcat = 1;
                request.setAttribute("articulos", ArticuloDAO.listarCat(idcat));
                request.getRequestDispatcher("WEB-INF/TiendaE.jsp").forward(request, response);
            }
            if(path.equals("/TiendaA")){
                int idcat = 3;
                request.setAttribute("articulos", ArticuloDAO.listarCat(idcat));
                request.getRequestDispatcher("WEB-INF/TiendaA.jsp").forward(request, response);
            }
            if(path.equals("/ShopS")){
                int id = Integer.parseInt(request.getParameter("id"));
                String nom = (String)(request.getParameter("nom"));
                String dsc = (String)(request.getParameter("dsc"));
                float precio = Float.parseFloat(request.getParameter("prec"));
                String foto = (String)(request.getParameter("fot"));
                int idcat = Integer.parseInt(request.getParameter("idcat"));
                Articulo art = new Articulo (id, nom, dsc, precio, foto, idcat);
                request.setAttribute("art", art);
                request.setAttribute("articulos", ArticuloDAO.listarCat(idcat));
                request.getRequestDispatcher("shop-single.jsp").forward(request, response);
            }
            if(path.equals("/Seguir")){
                request.setAttribute("articulos", ArticuloDAO.listar());
                request.getRequestDispatcher("shop.jsp").forward(request, response);
            }
        }
    }

    // <editor-fold defaultstate="collapsed" desc="HttpServlet methods. Click on the + sign on the left to edit the code.">
    /**
     * Handles the HTTP <code>GET</code> method.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        try {
            processRequest(request, response);
        } catch (SQLException ex) {
            Logger.getLogger(ServletShop.class.getName()).log(Level.SEVERE, null, ex);
        }
    }

    /**
     * Handles the HTTP <code>POST</code> method.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        try {
            processRequest(request, response);
        } catch (SQLException ex) {
            Logger.getLogger(ServletShop.class.getName()).log(Level.SEVERE, null, ex);
        }
    }

    /**
     * Returns a short description of the servlet.
     *
     * @return a String containing servlet description
     */
    @Override
    public String getServletInfo() {
        return "Short description";
    }// </editor-fold>

}
