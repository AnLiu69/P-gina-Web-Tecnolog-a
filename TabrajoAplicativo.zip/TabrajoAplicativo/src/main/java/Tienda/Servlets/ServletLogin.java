/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Tienda.Servlets;

import Tienda.modelo.DAO.PaisDAO;
import Tienda.modelo.bean.Cliente;
import Tienda.modelo.bean.Empleado;
import Tienda.modelo.bean.Pais;
import java.io.IOException;
import java.io.PrintWriter;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

/**
 *
 * @author ADMIN
 */
@WebServlet(name = "ServletLogin", urlPatterns = {"/ServletLogin", "/Login"})
public class ServletLogin extends HttpServlet {

    /**
     * Processes requests for both HTTP <code>GET</code> and <code>POST</code>
     * methods.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    protected void processRequest(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        response.setContentType("text/html;charset=UTF-8");
        try (PrintWriter out = response.getWriter()) {
            String path = request.getServletPath();
            
            if(path.equals("/Login")){
                HttpSession session1 = request.getSession(false);
                if(session1 != null && session1.getAttribute("cliente") != null){
                    HttpSession session = request.getSession();
                    Cliente cliente = (Cliente)session.getAttribute("cliente");
                    int idcli = cliente.getIdCliente();
                    int idps = cliente.getIdpais();
                    Pais pais = PaisDAO.obtenerPais(idps);
                    String paisN = pais.getPais();
                    request.setAttribute("cliente", cliente);
                    request.setAttribute("pais", paisN);
                    request.getRequestDispatcher("WEB-INF/Perfil.jsp").forward(request, response);
                }
                if(session1 != null && session1.getAttribute("empleado") != null){
                    HttpSession session = request.getSession();
                    Empleado empleado = (Empleado)session.getAttribute("empleado");
                    request.setAttribute("empleado", empleado);
                    request.getRequestDispatcher("WEB-INF/PerfilT.jsp").forward(request, response);
                }
                else{
                    request.getRequestDispatcher("WEB-INF/Login.jsp").forward(request, response);
                }
            }
        }
    }

    // <editor-fold defaultstate="collapsed" desc="HttpServlet methods. Click on the + sign on the left to edit the code.">
    /**
     * Handles the HTTP <code>GET</code> method.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        processRequest(request, response);
    }

    /**
     * Handles the HTTP <code>POST</code> method.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        processRequest(request, response);
    }

    /**
     * Returns a short description of the servlet.
     *
     * @return a String containing servlet description
     */
    @Override
    public String getServletInfo() {
        return "Short description";
    }// </editor-fold>

}
