/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Tienda.Servlets;

import Tienda.modelo.DAO.CarritoDAO;
import Tienda.modelo.DAO.EmpleadoDAO;
import Tienda.modelo.DAO.PedidoDAO;
import Tienda.modelo.DAO.PedidoDetalleDAO;
import Tienda.modelo.bean.Carrito;
import Tienda.modelo.bean.Cliente;
import Tienda.modelo.bean.Empleado;
import Tienda.modelo.bean.Pedido;
import Tienda.modelo.bean.PedidoDetalle;
import java.io.IOException;
import java.io.PrintWriter;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.Random;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

/**
 *
 * @author ADMIN
 */
@WebServlet(name = "ServletCarrito", urlPatterns = {"/ServletCarrito", "/Carrito", "/EliminarC", "/Info"})
public class ServletCarrito extends HttpServlet {

    /**
     * Processes requests for both HTTP <code>GET</code> and <code>POST</code>
     * methods.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    protected void processRequest(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException, SQLException {
        response.setContentType("text/html;charset=UTF-8");
        try (PrintWriter out = response.getWriter()) {
           String path = request.getServletPath();
           
           if(path.equals("/Carrito")){
                HttpSession session1 = request.getSession(false);
                if(session1 != null && session1.getAttribute("cliente") != null){
                    HttpSession session = request.getSession();
                    Cliente cliente = (Cliente)session.getAttribute("cliente");
                    int idcli = cliente.getIdCliente();
                    ArrayList<Carrito> carritolista = new ArrayList<>();
                    carritolista = CarritoDAO.listarCli(idcli);
                    ArrayList<Float> subts = new ArrayList<Float>();
                    for(Carrito x: carritolista){
                    subts.add(x.getSubtotal());
                    }
                    float suma = 0;
                    for (float numero : subts) {
                        suma += numero;
                    }
                    request.setAttribute("total", suma);
                    request.setAttribute("listacarrito", carritolista);
                    request.getRequestDispatcher("WEB-INF/Carrito.jsp").forward(request, response);
                }
                else{
                    request.getRequestDispatcher("WEB-INF/Login.jsp").forward(request, response);
                }
           }
           if(path.equals("/EliminarC")){
               
               int idcli = Integer.parseInt(request.getParameter("idcli"));
               int idcarr = Integer.parseInt(request.getParameter("idcarr"));
               ArrayList<Carrito> carritolista = new ArrayList<>();
               CarritoDAO.eliminarArt(idcarr);
               carritolista = CarritoDAO.listarCli(idcli);
               request.setAttribute("listacarrito", carritolista);
               request.getRequestDispatcher("WEB-INF/Carrito.jsp").forward(request, response);
           }
           if(path.equals("/Info")){
            
                HttpSession session1 = request.getSession(false);
                if(session1 != null && session1.getAttribute("cliente") != null){
                    float tot = Float.parseFloat(request.getParameter("total"));
                    ArrayList<Empleado> empleados = EmpleadoDAO.listar();
                    ArrayList<Integer> idempls = new ArrayList<Integer>();
                    for(Empleado x: empleados){
                            idempls.add(x.getIdempleado());
                    }
                    Random rand = new Random();
                    int idacargo = idempls.get(rand.nextInt(idempls.size()));
                    HttpSession session = request.getSession();
                    Cliente cliente = (Cliente)session.getAttribute("cliente");
                    int idcli = cliente.getIdCliente();
                    
                    Carrito carritoFecha = CarritoDAO.EncontrarFech(idcli);
                    String fecha = carritoFecha.getFecha();
                    
                    Pedido ped = new Pedido(0, fecha, tot, idcli, idacargo);
                    PedidoDAO.insertar(ped);

                    Pedido pednw = PedidoDAO.seleccionarID(idcli);
                    int idpedido = pednw.getIdpedido();
                    ArrayList<Carrito> carritos = CarritoDAO.listarCli(idcli);
                
                    for(Carrito x: carritos){
                            PedidoDetalle pedidoD = new PedidoDetalle(0, idpedido, x.getIdarticulo(), x.getPrecioA(), x.getCantidad(), x.getSubtotal());
                            PedidoDetalleDAO.insertar(pedidoD);
                    }
                    request.getRequestDispatcher("WEB-INF/PostVenta.jsp").forward(request, response);
                }
                else{
                    request.getRequestDispatcher("Inicio.jsp").forward(request, response);
                }
                    /*HttpSession session = request.getSession();
                    Cliente cliente = (Cliente)session.getAttribute("cliente");
                    int idcli = cliente.getIdCliente();
                    request.setAttribute("idcli", idcli);
                    request.getRequestDispatcher("Testeo.jsp").forward(request, response);*/
            }
           
        }  
    }

    // <editor-fold defaultstate="collapsed" desc="HttpServlet methods. Click on the + sign on the left to edit the code.">
    /**
     * Handles the HTTP <code>GET</code> method.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        try {
            processRequest(request, response);
        } catch (SQLException ex) {
            Logger.getLogger(ServletCarrito.class.getName()).log(Level.SEVERE, null, ex);
        }
    }

    /**
     * Handles the HTTP <code>POST</code> method.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        try {
            processRequest(request, response);
        } catch (SQLException ex) {
            Logger.getLogger(ServletCarrito.class.getName()).log(Level.SEVERE, null, ex);
        }
    }

    /**
     * Returns a short description of the servlet.
     *
     * @return a String containing servlet description
     */
    @Override
    public String getServletInfo() {
        return "Short description";
    }// </editor-fold>

}
