package Tienda.Conexion;

import java.sql.Connection;
import java.sql.DriverManager;

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author ADMIN
 */
public class Conexion {
   //atributos estaticos
    private static String url="jdbc:mysql://localhost/tiendaonline";
    private static String usuario="root";
    private static String password="12345678";
    private static Connection cn;
    //metodo para abrir la conexion
    public static Connection abrir(){
        try {
            //registrar driver
            Class.forName("com.mysql.jdbc.Driver");
            //abrir la conexion
            cn = DriverManager.getConnection(url, usuario, password);
            return cn;
        } catch (Exception ex) {
            return null;
        }
    }
}
